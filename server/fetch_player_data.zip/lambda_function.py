import json
import boto3
from boto3.dynamodb.conditions import Key,Attr 

def lambda_handler(event, context):
    # TODO implement
    #print(event)
    matchid = event['MatchId']
    name = event['name']
    #print(type(matchid))
    #print(matchid)
    dynamodb = boto3.resource('dynamodb') 
    match_table = dynamodb.Table('dr11-publicmatch') 
    matchResponse  = match_table.scan( 
        FilterExpression = Attr('MatchId').eq(matchid) 
    ) 
    #print(matchResponse)
    team1_list =  matchResponse['Items'][0]['Team1 Players']
    print(team1_list)
    #team1_modified = []
    #for i in range(len(team1_list)):
    #     if(team1_list[i].isdigit()):
    #         print(team1_list[i])
    #         team1_modified.append(team1_list)
    
    #print('872658732652897',team1_modified)     
         
    team2_list =  matchResponse['Items'][0]['Team2 Players']
    # for i in range(len(team2_list)):
    #     team2_list[i] = int(team2_list[i])
    
    playersResponse = []
    #print(team2_list)
    Cricket_Player_table = dynamodb.Table('dr11-playerdata') 
    for i in range(11):
        currentresponse  = Cricket_Player_table.scan(FilterExpression = (Attr('playerid').eq(team1_list[i])))
        currentresponse =currentresponse['Items'][0]
        playersResponse.append(currentresponse)
    
    for i in range(11):
        currentresponse  = Cricket_Player_table.scan(FilterExpression = (Attr('playerid').eq(team2_list[i])))
        currentresponse =currentresponse['Items'][0]
        playersResponse.append(currentresponse)

    print('**********', playersResponse)
    #print(playersResponse)
    #playersResponse=playersResponse["Items"]
    print(len(playersResponse))
    result={}
    for i in range(len(playersResponse)):
        result[i] = {
            'playerid':playersResponse[i]['playerid'],
            'credits':playersResponse[i]['credits'],
            'category':playersResponse[i]['category'],
            'playername':playersResponse[i]['playername'],
            'points':playersResponse[i]['points']
        }
    print(result)
    # print(type(playerid))
    # print(type(credits))
    # print(type(points))
    #print(scanExpression)
    '''
    result2=[]
    for i in range(len(result)):
        result2.append({
          result[i]
    })
    print(result2)
    '''
    return { 
         'statusCode': 200, 
         'headers': { 
                 "Access-Control-Allow-Origin" : "*", # Required for CORS support to work 
                 "Access-Control-Allow-Credentials" : True # Required for cookies, authorization headers with HTTPS  
               }, 
        #'body': json.dumps(playersResponse['Items']) 
        #"body": json.dumps({"playerid":playerid,"credits":int(credits),"category":category,"playername":playername,"points":int(points)})
         'body': {'Username':name,'Playerdata':result}
    } 
    
