import json
import boto3
from boto3.dynamodb.conditions import Key,Attr 

def lambda_handler(event, context):
    # TODO implement
    #print(event)
    list1 = event['squad']
    print(list1)
    print(type(list1))
    dynamodb = boto3.resource('dynamodb') 
    match_table = dynamodb.Table('dr11-playerdata') 
    # matchResponse  = match_table.scan( 
    #     FilterExpression = Attr('MatchId').
    #     Cricket_Player_table = dynamodb.Table('dr11-playerdata') 
    #matchresponse=matchresponse["Items"]
    playersResponse=[]
    state = "True"
    if(len(list1)!=11):
        state ="False"
        msg= "You have not selected 11 players"
    for i in range(len(list1)):
        matchresponse  = match_table.scan(FilterExpression = (Attr('playerid').eq(list1[i])))
        matchresponse =matchresponse['Items'][0]
        playersResponse.append(matchresponse)
    print(playersResponse)  
    print(len(playersResponse))
    result=[]
    for i in range(len(playersResponse)):
        result.append(playersResponse[i]['category'])
        
    print(result)    
    bow=[]
    bat=[]
    wk=[]
    all1=[]
    countbow=0
    countbat=0
    countwk=0
    countall1=0
    for i in range(len(result)):
        #print(result[i])
        if result[i] == "bo":
            bow.append(result[i])
            countbow+=1
        elif result[i] == "ba":
            bat.append(result[i])
            countbat+=1
        elif result[i] == "wk":
            wk.append(result[i])
            countwk+=1
        else:
            all1.append(result[i])
            countall1+=1
            
    # print(countbow)
    # print(countbat)
    # print(countwk)
    # print(countall1)
    if countbow != 4:
        state ="False"
        msg="The number of bowlers you should select are four"
    if countbat != 4:
        state ="False"
        msg="The number of batsman you should select are four"
    if countwk != 1:
        state ="False"
        msg="The number of wicket keepers you should are one"    
    if countall1 != 2:
        state ="False"
        msg="The number of all rounders you should select are one"    
    return { 
         'statusCode': 200, 
         'headers': { 
                 "Access-Control-Allow-Origin" : "*", # Required for CORS support to work 
                 "Access-Control-Allow-Credentials" : True # Required for cookies, authorization headers with HTTPS  
               }, 
        #'body': json.dumps(playersResponse['Items']) 
        #"body": json.dumps({"playerid":playerid,"credits":int(credits),"category":category,"playername":playername,"points":int(points)})
         'body': {'State':state,'Message':msg}
    }     