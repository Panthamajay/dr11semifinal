import json
import boto3
from boto3.dynamodb.conditions import Key,Attr 

def lambda_handler(event, context):
    # TODO implement
    leagueid = event['LeagueId']
    #privateid = event['privateid']
    dynamodb = boto3.resource('dynamodb')
    # match_table = dynamodb.Table('dr11-publicmatch') 
    # matchResponse  = match_table.scan(
    #     FilterExpression = Attr('LeagueId').eq(leagueid)
    #  )
    # print(matchResponse)
    # list_matchid=[]
    # #for i in range(len(matchResponse)):
    # #print(len(matchResponse))
    # matchResponse=matchResponse["Items"]
    # print(matchResponse)
    # print(len(matchResponse))
    # for i in range(len(matchResponse)): 
    #     print('this is i', i)
    #     #MatchId=int(MatchId)
    #     print(type(i))
    #     #i=int(i)
    #     #list_matchid[i]= matchResponse['Items']['i']['MatchId']
    #     list_matchid.append(
    #         matchResponse[i]['MatchId'])
    #     #print('******')
    #     print(list_matchid[i])
    #     #team1_list =  list(matchResponse['Items'][0]['Team1 Players']) 
    # #list_matchid = matchResponse['Items'][0]['MatchId'] 
    # print(list_matchid)
    #print(len(matchResponse))
    #print(len(list_matchid))
    #print(list_matchid)
    
    #print(matchResponse)
    match_table1 = dynamodb.Table('dr11-usermatchhistory') 
    matchResponse1  = match_table1.scan(
        FilterExpression = Attr('leagueid').eq(leagueid)
     )
    print(matchResponse1)
    # match_list=[] 
    # matchResponse1=matchResponse1["Items"]
    # for i in range(len(matchResponse1)):
    #     print('this is i', i)
    #     print(type(i))
    #     match_list.append(matchResponse1[i]['matchid']) 
    # print(match_list)
    # print(len(match_list))
    #print(matchResponse1) 
    
    result=[] 
    #print(int(matchResponse1[0][UserTeamPoints]))
    #print(matchResponse1)
    #print(len(matchResponse1))
    #print(Matchid)
    # for i in range(len(matchResponse1)): 
    #     for j in range(len(matchResponse)):
    #       if (matchResponse1[i]['matchid'])==list_matchid[j]: 
    #         result.append([matchResponse1[i]['name'], matchResponse1[i]["UserTeamPoints"]]) 
    matchResponse1=matchResponse1["Items"]
    for i in range(len(matchResponse1)): 
        if (matchResponse1[i]['leagueid'])==leagueid: 
            result.append([matchResponse1[i]['name'], matchResponse1[i]["UserTeamPoints"]]) 
      
    for i in range(len(result)): 
        result[i][1]=int(result[i][1]) 
             
    result=sorted(result, key=lambda x:x[1]) 
     
    result=result[-1::-1] 
    print(result)
    resp=[] 
    #print(result) 
    count=1
    for i in range(len(result)): 
              curr_user=result[i][0]
              curr_score=result[i][1] 
              resp.append({ 
              'Username':result[i][0],
              'Score':result[i][1], 
              'Rank':count
          }) 
              count+=1
    print(resp)          
    return resp
    

