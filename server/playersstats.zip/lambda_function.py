import boto3
import json
from boto3.dynamodb.conditions import Key, Attr
import decimal


def lambda_handler(event, context):
    # TODO implement
    name1=event['name']
    dynamo_db = boto3.resource('dynamodb') 
    match_table = dynamo_db.Table('dr11-playerdata')
    playersResponse = match_table.scan()['Items']
    
    print(playersResponse)
    print(len(playersResponse))
    result={}
    for i in range(len(playersResponse)):
        result[i] = {
            'playerid':playersResponse[i]['playerid'],
            'credits':playersResponse[i]['credits'],
            'category':playersResponse[i]['category'],
            'playername':playersResponse[i]['playername'],
            'points':playersResponse[i]['points']
        }
    print(result)
    
    return { 
         'statusCode': 200, 
         'headers': { 
                 "Access-Control-Allow-Origin" : "*", # Required for CORS support to work 
                 "Access-Control-Allow-Credentials" : True # Required for cookies, authorization headers with HTTPS  
               }, 
        #'body': json.dumps(playersResponse['Items']) 
        #"body": json.dumps({"playerid":playerid,"credits":int(credits),"category":category,"playername":playername,"points":int(points)})
         'body': {'Username':name1,'Playerdata':result}
    } 