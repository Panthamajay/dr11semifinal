import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime


def lambda_handler(event, context):
    name= event['username']
    dynamodb = boto3.resource("dynamodb")
    match_history = dynamodb.Table('dr11-publicmatch') 
    response = match_history.scan()
    all_matches_record=[]
    for i in range (response['Count']):
        date = response['Items'][i]['Date']
        datesplit = date.split('/')
        year =int(datesplit[2])
        month = int(datesplit[1])
        day = int(datesplit[0])
        t = datetime(year, month, day, int(response['Items'][i]['Hours']), int(response['Items'][i]['Minutes']), 0, 0)
        now = datetime.now()
        seconds = (t-now).total_seconds()
        print(seconds)
        timelimit = True
        if(seconds<3600):
            timelimit =False

        if(response['Items'][i]['status1']=='active' and timelimit):
            all_matches_record.append({
                            'Team1': response['Items'][i]['Team'],
                            'Team2': response['Items'][i]['Team2'],
                            'Hours' : response['Items'][i]['Hours'],
                            'Minutes' : response['Items'][i]['Minutes'],
                            'LeagueId' : response['Items'][i]['LeagueId'],
                            'MatchId' : response['Items'][i]['MatchId'],
                            'PrivateId' : str(0)
                            
            })

    all_matches_json={}
    all_matches_json['AllMatches']=all_matches_record  
   
    return { 
         'statusCode': 200, 
         'headers': { 
                 "Access-Control-Allow-Origin" : "*", # Required for CORS support to work 
                 "Access-Control-Allow-Credentials" : True # Required for cookies, authorization headers with HTTPS  
               }, 
        #'body': json.dumps(playersResponse['Items']) 
        #"body": json.dumps({"playerid":playerid,"credits":int(credits),"category":category,"playername":playername,"points":int(points)})
         'body': {'Username':name,'MatchInfo':all_matches_json}
    } 
    
    
    
    
    

